# Motor Browser

Navegador Android com motor próprio (Kotlin). Sem Chromium, Firefox ou WebView.

## Compilar
Faça push para o GitHub → aba **Actions** → "Build APK" → baixe o artefato `MotorBrowser-apk`.

## Roteiro
- [x] Rede (HttpURLConnection) com redirecionamentos
- [x] Parser HTML (tokenizer + DOM)
- [x] Layout block/inline + render em Canvas + links
- [ ] Parser CSS (seletores, cascata, herança)
- [ ] Box model completo, bordas, cores de fundo
- [ ] Imagens
- [ ] JavaScript (QuickJS via NDK)
- [ ] Abas, favoritos, histórico
